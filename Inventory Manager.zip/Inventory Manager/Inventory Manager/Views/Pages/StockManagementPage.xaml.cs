﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;
using System.ComponentModel;
using System.IO;
using ClosedXML.Excel;
using System.Windows.Media;

namespace InventoryManager.Views.Pages
{
    public partial class StockManagementPage : Page
    {
        private List<InventoryItem> _originalItems;
        private List<InventoryItem> _allItems;
        private List<InventoryItem> _currentPageItems;
        private int _currentPage = 1;
        private const int ItemsPerPage = 7;

        public StockManagementPage()
        {
            InitializeComponent();
            Loaded += StockManagementPage_Loaded;
        }

        private void StockManagementPage_Loaded(object sender, RoutedEventArgs e)
        {
            LoadInventoryData();
        }

        private void LoadInventoryData()
        {
            try
            {
                ShowLoading(true);
                _originalItems = GetSampleInventoryData();
                _allItems = new List<InventoryItem>(_originalItems);
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
            finally
            {
                ShowLoading(false);
            }
        }

        private List<InventoryItem> GetSampleInventoryData()
        {
            return new List<InventoryItem>
            {
                new InventoryItem(1, "Premium Almonds", "Nuts", 150, "kg", 15.99m, DateTime.Now.AddDays(-2)),
                new InventoryItem(2, "Golden Cashews", "Nuts", 85, "kg", 18.50m, DateTime.Now.AddDays(-1)),
                new InventoryItem(3, "Organic Walnuts", "Nuts", 0, "kg", 12.75m, DateTime.Now),
                new InventoryItem(4, "Royal Pistachios", "Nuts", 65, "kg", 22.25m, DateTime.Now.AddDays(-3)),
                new InventoryItem(5, "Black Raisins", "Dry Fruits", 200, "kg", 8.99m, DateTime.Now.AddDays(-5)),
                new InventoryItem(6, "Medjool Dates", "Dry Fruits", 90, "kg", 10.45m, DateTime.Now.AddDays(-1)),
                new InventoryItem(7, "Ceylon Cinnamon", "Spices", 50, "kg", 25.00m, DateTime.Now.AddDays(-7)),
                new InventoryItem(8, "Green Cardamom", "Spices", 40, "kg", 32.50m, DateTime.Now.AddDays(-4))
            };
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ShowLoading(true);
                var dialog = new AddEditInventoryDialog();
                if (dialog.ShowDialog() == true && dialog.InventoryItem != null)
                {
                    if (ValidateInventoryItem(dialog.InventoryItem))
                    {
                        dialog.InventoryItem.Id = _originalItems.Count > 0 ?
                            _originalItems.Max(item => item.Id) + 1 : 1;
                        _originalItems.Add(dialog.InventoryItem);
                        ApplyFilters();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding item: {ex.Message}", "Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                ShowLoading(false);
            }
        }

        private void EditItem_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryGrid.SelectedItem is InventoryItem selectedItem)
            {
                try
                {
                    ShowLoading(true);
                    var dialog = new AddEditInventoryDialog(selectedItem);
                    if (dialog.ShowDialog() == true && dialog.InventoryItem != null)
                    {
                        if (ValidateInventoryItem(dialog.InventoryItem))
                        {
                            // Find and update the item in original collection
                            var itemToUpdate = _originalItems.FirstOrDefault(item => item.Id == selectedItem.Id);
                            if (itemToUpdate != null)
                            {
                                itemToUpdate.Name = dialog.InventoryItem.Name;
                                itemToUpdate.Category = dialog.InventoryItem.Category;
                                itemToUpdate.Quantity = dialog.InventoryItem.Quantity;
                                itemToUpdate.Unit = dialog.InventoryItem.Unit;
                                itemToUpdate.Price = dialog.InventoryItem.Price;
                                itemToUpdate.LastUpdated = DateTime.Now;
                            }
                            ApplyFilters();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error editing item: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    ShowLoading(false);
                }
            }
            else
            {
                MessageBox.Show("Please select an item to edit.", "Warning",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteItem_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryGrid.SelectedItem is InventoryItem selectedItem)
            {
                var result = MessageBox.Show($"Are you sure you want to delete {selectedItem.Name}?",
                    "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        ShowLoading(true);
                        _originalItems.RemoveAll(item => item.Id == selectedItem.Id);
                        ApplyFilters();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error deleting item: {ex.Message}", "Error",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    finally
                    {
                        ShowLoading(false);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an item to delete.", "Warning",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private bool ValidateInventoryItem(InventoryItem item)
        {
            if (string.IsNullOrWhiteSpace(item.Name))
            {
                MessageBox.Show("Product name cannot be empty", "Validation Error",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (item.Quantity < 0)
            {
                MessageBox.Show("Quantity cannot be negative", "Validation Error",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (item.Price < 0)
            {
                MessageBox.Show("Price cannot be negative", "Validation Error",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void ResetFilters_Click(object sender, RoutedEventArgs e)
        {
            SearchBox.Text = string.Empty;
            CategoryFilter.SelectedIndex = 0;
            _allItems = new List<InventoryItem>(_originalItems);
            _currentPage = 1;
            ApplyPaging();
            InventoryGrid.ItemsSource = _currentPageItems;
            UpdateStatusBar();
        }

        private void ApplyFilters()
        {
            try
            {
                ShowLoading(true);
                var filteredItems = _originalItems.AsEnumerable();

                // Apply search filter
                if (!string.IsNullOrWhiteSpace(SearchBox.Text))
                {
                    string searchText = SearchBox.Text.ToLower();
                    filteredItems = filteredItems.Where(item =>
                        item.Name.ToLower().Contains(searchText) ||
                        item.Category.ToLower().Contains(searchText));
                }

                // Apply category filter
                if (CategoryFilter.SelectedItem is ComboBoxItem selectedItem)
                {
                    string selectedCategory = selectedItem.Content.ToString();
                    if (selectedCategory != "All Categories")
                    {
                        filteredItems = filteredItems.Where(item =>
                            item.Category == selectedCategory);
                    }
                }

                _allItems = filteredItems.ToList();
                _currentPage = 1;
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
            finally
            {
                ShowLoading(false);
            }
        }

        private void ApplyPaging()
        {
            int itemCount = _allItems.Count;
            int skipCount = (_currentPage - 1) * ItemsPerPage;

            _currentPageItems = itemCount == 0
                ? new List<InventoryItem>()
                : _allItems.Skip(skipCount).Take(ItemsPerPage).ToList();
        }

        private void UpdateStatusBar()
        {
            int itemCount = _allItems.Count;
            int totalPages = itemCount == 0 ? 1 : (int)Math.Ceiling((double)itemCount / ItemsPerPage);

            StatusText.Text = itemCount == 0
                ? "No items found"
                : $"{itemCount} items in inventory (showing {_currentPageItems.Count})";

            PageInfoText.Text = $"Page {Math.Min(_currentPage, totalPages)} of {totalPages}";

            PreviousPageButton.IsEnabled = _currentPage > 1;
            NextPageButton.IsEnabled = _currentPage < totalPages && itemCount > 0;
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|CSV Files (*.csv)|*.csv",
                Title = "Export Inventory Data",
                DefaultExt = ".xlsx"
            };

            if (saveDialog.ShowDialog() == true)
            {
                try
                {
                    ShowLoading(true);

                    if (Path.GetExtension(saveDialog.FileName).ToLower() == ".xlsx")
                    {
                        ExportToExcelXlsx(saveDialog.FileName);
                    }
                    else
                    {
                        ExportToCsv(saveDialog.FileName);
                    }

                    MessageBox.Show("Export completed successfully!", "Success",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error during export: {ex.Message}", "Error",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    ShowLoading(false);
                }
            }
        }

        private void ExportToExcelXlsx(string filePath)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("Inventory");

                // Add headers
                worksheet.Cell(1, 1).Value = "ID";
                worksheet.Cell(1, 2).Value = "Product Name";
                worksheet.Cell(1, 3).Value = "Category";
                worksheet.Cell(1, 4).Value = "Quantity";
                worksheet.Cell(1, 5).Value = "Unit";
                worksheet.Cell(1, 6).Value = "Price";
                worksheet.Cell(1, 7).Value = "Last Updated";

                // Format headers
                var headerRange = worksheet.Range("A1:G1");
                headerRange.Style.Font.Bold = true;
                headerRange.Style.Fill.BackgroundColor = XLColor.LightGray;

                // Add data
                int row = 2;
                foreach (var item in _allItems)
                {
                    worksheet.Cell(row, 1).Value = item.Id;
                    worksheet.Cell(row, 2).Value = item.Name;
                    worksheet.Cell(row, 3).Value = item.Category;
                    worksheet.Cell(row, 4).Value = item.Quantity;
                    worksheet.Cell(row, 5).Value = item.Unit;
                    worksheet.Cell(row, 6).Value = item.Price;
                    worksheet.Cell(row, 7).Value = item.LastUpdated;
                    row++;
                }

                // Auto-fit columns
                worksheet.Columns().AdjustToContents();

                workbook.SaveAs(filePath);
            }
        }

        private void ExportToCsv(string filePath)
        {
            var lines = new List<string> { "ID,Name,Category,Quantity,Unit,Price,LastUpdated" };
            lines.AddRange(_allItems.Select(item =>
                $"{item.Id},\"{item.Name}\",{item.Category},{item.Quantity},{item.Unit},{item.Price},{item.LastUpdated:d}"));

            File.WriteAllLines(filePath, lines);
        }

        private void PreviousPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage > 1)
            {
                _currentPage--;
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            int totalPages = (int)Math.Ceiling((double)_allItems.Count / ItemsPerPage);
            if (_currentPage < totalPages)
            {
                _currentPage++;
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
        }

        private void ShowLoading(bool show)
        {
            LoadingOverlay.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
            AddButton.IsEnabled = !show;
            ExportButton.IsEnabled = !show;
        }

        private void InventoryGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Optional: Add any selection change logic here
        }
    }

    public class InventoryItem : INotifyPropertyChanged, IDataErrorInfo
    {
        public int Id { get; set; }

        private string _name;
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        private string _category;
        public string Category
        {
            get => _category;
            set { _category = value; OnPropertyChanged(nameof(Category)); }
        }

        private int _quantity;
        public int Quantity
        {
            get => _quantity;
            set { _quantity = value; OnPropertyChanged(nameof(Quantity)); }
        }

        private string _unit;
        public string Unit
        {
            get => _unit;
            set { _unit = value; OnPropertyChanged(nameof(Unit)); }
        }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged(nameof(Price)); }
        }

        private DateTime _lastUpdated;
        public DateTime LastUpdated
        {
            get => _lastUpdated;
            set { _lastUpdated = value; OnPropertyChanged(nameof(LastUpdated)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public string Error => null;

        public string this[string columnName]
        {
            get
            {
                // Implement validation logic here if needed
                return null;
            }
        }
    }
}
