﻿using System.Windows.Controls;

namespace InventoryManager.Views.Pages
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
        }
    }
}