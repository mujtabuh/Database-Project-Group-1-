﻿using System.Windows;
using System.Windows.Controls;
using InventoryManager.Views.Pages;

namespace InventoryManager
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new StockManagementPage());
            SetActiveButton(StockManagementButton);
        }

        private void SetActiveButton(Button activeButton)
        {
            StockManagementButton.Style = (Style)FindResource("SidebarButtonStyle");
            ProductManagementButton.Style = (Style)FindResource("SidebarButtonStyle");
            ProductLookupButton.Style = (Style)FindResource("SidebarButtonStyle");
            ReportsButton.Style = (Style)FindResource("SidebarButtonStyle");

            activeButton.Style = (Style)FindResource("ActiveSidebarButtonStyle");
        }

        private void NavigateToPage(Page page)
        {
            MainFrame.Navigate(page);
        }

        private void StockManagement_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new StockManagementPage());
            SetActiveButton(StockManagementButton);
        }

        private void ProductManagement_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new ProductManagementPage());
            SetActiveButton(ProductManagementButton);
        }

        private void ProductLookup_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new ProductLookupPage());
            SetActiveButton(ProductLookupButton);
        }

        private void Reports_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPage(new ReportsPage());
            SetActiveButton(ReportsButton);
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to logout?", "Logout Confirmation",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        public void ToggleSidebar()
        {
            SidebarColumn.Width = SidebarColumn.Width.Value > 0 ?
                new GridLength(0) :
                new GridLength(260);
        }
    }
}