﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace InventoryManager.Controls
{
    public partial class TopNavBar : UserControl
    {
        public TopNavBar()
        {
            InitializeComponent();
            SearchBox.GotFocus += SearchBox_GotFocus;
            SearchBox.LostFocus += SearchBox_LostFocus;
            SearchBox.KeyUp += SearchBox_KeyUp;
        }

        private void ToggleSidebarBtn_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.ToggleSidebar();
        }

        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SearchBox.Text == "🔍 Search products, inventory...")
            {
                SearchBox.Text = "";
                SearchBox.Foreground = Brushes.Black;
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                SearchBox.Text = "🔍 Search products, inventory...";
                SearchBox.Foreground = Brushes.Gray;
            }
        }

        private void SearchBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Handle search functionality here
            }
        }

        private void ProfileBtn_Click(object sender, RoutedEventArgs e)
        {
            // Handle profile button click
        }
    }
}