﻿using System;
using System.Windows.Data;
using System.Windows.Media;
using System.Globalization;

namespace InventoryManager.Converters
{
    public class QuantityToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is int quantity)
            {
                if (quantity == 0)
                    return new SolidColorBrush(Color.FromRgb(0xFF, 0x52, 0x52)); // Red
                if (quantity < 10)
                    return new SolidColorBrush(Color.FromRgb(0xFF, 0xA7, 0x26)); // Orange
                return new SolidColorBrush(Color.FromRgb(0x66, 0xBB, 0x6A)); // Green
            }
            return Brushes.Transparent;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}