﻿using System.Windows.Controls;
using System.ComponentModel;

namespace InventoryManager.Views.Pages
{
    public class BasePage : Page, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public virtual void PerformSearch(string searchTerm) { }
    }
}