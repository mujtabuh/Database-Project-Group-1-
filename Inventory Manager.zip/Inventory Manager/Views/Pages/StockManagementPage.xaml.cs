﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.Win32;
using System.ComponentModel;
using System.IO;
using System.Globalization;

namespace InventoryManager.Views.Pages
{
    public partial class StockManagementPage : Page
    {
        private List<InventoryItem> _allItems;
        private List<InventoryItem> _displayedItems;
        private List<InventoryItem> _currentPageItems;
        private int _currentPage = 1;
        private const int ItemsPerPage = 7;
        private string _lastSortColumn = "Id";
        private ListSortDirection _lastSortDirection = ListSortDirection.Ascending;

        public StockManagementPage()
        {
            InitializeComponent();
            Loaded += StockManagementPage_Loaded;
        }

        private void StockManagementPage_Loaded(object sender, RoutedEventArgs e)
        {
            _allItems = LoadInventoryData();
            _displayedItems = new List<InventoryItem>(_allItems);
            ApplyPaging();
            InventoryGrid.ItemsSource = _currentPageItems;
            UpdateStatusBar();
        }

        private List<InventoryItem> LoadInventoryData()
        {
            return new List<InventoryItem>
            {
                new InventoryItem(1, "Premium Almonds", "Nuts", 150, "kg", 15.99m, DateTime.Now.AddDays(-2)),
                new InventoryItem(2, "Golden Cashews", "Nuts", 85, "kg", 18.50m, DateTime.Now.AddDays(-1)),
                new InventoryItem(3, "Organic Walnuts", "Nuts", 0, "kg", 12.75m, DateTime.Now),
                new InventoryItem(4, "Royal Pistachios", "Nuts", 65, "kg", 22.25m, DateTime.Now.AddDays(-3)),
                new InventoryItem(5, "Black Raisins", "Dry Fruits", 200, "kg", 8.99m, DateTime.Now.AddDays(-5)),
                new InventoryItem(6, "Medjool Dates", "Dry Fruits", 90, "kg", 10.45m, DateTime.Now.AddDays(-1)),
                new InventoryItem(7, "Ceylon Cinnamon", "Spices", 50, "kg", 25.00m, DateTime.Now.AddDays(-7)),
                new InventoryItem(8, "Green Cardamom", "Spices", 40, "kg", 32.50m, DateTime.Now.AddDays(-4))
            };
        }

        private void AddItem_Click(object sender, RoutedEventArgs e)
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox("Enter product name:", "Add New Item", "");
            if (string.IsNullOrWhiteSpace(name)) return;

            string category = Microsoft.VisualBasic.Interaction.InputBox("Enter category (Nuts/Dry Fruits/Spices):", "Add New Item", "Nuts");
            string quantityStr = Microsoft.VisualBasic.Interaction.InputBox("Enter quantity:", "Add New Item", "0");
            string unit = Microsoft.VisualBasic.Interaction.InputBox("Enter unit (kg/lb/etc):", "Add New Item", "kg");
            string priceStr = Microsoft.VisualBasic.Interaction.InputBox("Enter price:", "Add New Item", "0.00");

            if (!int.TryParse(quantityStr, out int quantity)) quantity = 0;
            if (!decimal.TryParse(priceStr, out decimal price)) price = 0;

            var newItem = new InventoryItem(
                id: _allItems.Count > 0 ? _allItems.Max(item => item.Id) + 1 : 1,
                name: name,
                category: category,
                quantity: quantity,
                unit: unit,
                price: price,
                lastUpdated: DateTime.Now
            );

            _allItems.Add(newItem);
            _displayedItems = new List<InventoryItem>(_allItems);
            ApplyFilters(false);
            UpdateStatusBar();
        }

        private void EditItem_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryGrid.SelectedItem is InventoryItem selectedItem)
            {
                string newName = Microsoft.VisualBasic.Interaction.InputBox("Edit product name:", "Edit Item", selectedItem.Name);
                if (!string.IsNullOrWhiteSpace(newName)) selectedItem.Name = newName;

                string newCategory = Microsoft.VisualBasic.Interaction.InputBox("Edit category:", "Edit Item", selectedItem.Category);
                if (!string.IsNullOrWhiteSpace(newCategory)) selectedItem.Category = newCategory;

                string newQuantity = Microsoft.VisualBasic.Interaction.InputBox("Edit quantity:", "Edit Item", selectedItem.Quantity.ToString());
                if (int.TryParse(newQuantity, out int quantity)) selectedItem.Quantity = quantity;

                string newUnit = Microsoft.VisualBasic.Interaction.InputBox("Edit unit:", "Edit Item", selectedItem.Unit);
                if (!string.IsNullOrWhiteSpace(newUnit)) selectedItem.Unit = newUnit;

                string newPrice = Microsoft.VisualBasic.Interaction.InputBox("Edit price:", "Edit Item", selectedItem.Price.ToString("0.00"));
                if (decimal.TryParse(newPrice, out decimal price)) selectedItem.Price = price;

                selectedItem.LastUpdated = DateTime.Now;
                InventoryGrid.Items.Refresh();
                UpdateStatusBar();
            }
            else
            {
                MessageBox.Show("Please select an item to edit.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteItem_Click(object sender, RoutedEventArgs e)
        {
            if (InventoryGrid.SelectedItem is InventoryItem selectedItem)
            {
                var result = MessageBox.Show($"Are you sure you want to delete {selectedItem.Name}?",
                    "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    _allItems.Remove(selectedItem);
                    _displayedItems.Remove(selectedItem);

                    int totalPages = (int)Math.Ceiling((double)_displayedItems.Count / ItemsPerPage);
                    if (_currentPage > totalPages && totalPages > 0)
                    {
                        _currentPage = totalPages;
                    }

                    ApplyPaging();
                    InventoryGrid.ItemsSource = _currentPageItems;
                    UpdateStatusBar();
                }
            }
            else
            {
                MessageBox.Show("Please select an item to delete.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ApplyFilters(true);
        }

        private void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyFilters(true);
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            ApplyFilters(true);
        }

        private void ApplyFilters(bool resetPage)
        {
            var filteredItems = _allItems.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                string searchText = SearchBox.Text.ToLower();
                filteredItems = filteredItems.Where(item =>
                    item.Name.ToLower().Contains(searchText) ||
                    item.Category.ToLower().Contains(searchText));
            }

            if (CategoryFilter.SelectedItem is ComboBoxItem selectedItem &&
                selectedItem.Content.ToString() != "All Categories")
            {
                filteredItems = filteredItems.Where(item =>
                    item.Category == selectedItem.Content.ToString());
            }

            _displayedItems = filteredItems.ToList();

            if (resetPage)
            {
                _currentPage = 1;
            }

            ApplyPaging();
            InventoryGrid.ItemsSource = _currentPageItems;
            UpdateStatusBar();
        }

        private void ApplyPaging()
        {
            int totalPages = (int)Math.Ceiling((double)_displayedItems.Count / ItemsPerPage);
            if (totalPages == 0) totalPages = 1;

            if (_currentPage > totalPages)
            {
                _currentPage = totalPages;
            }

            _currentPageItems = _displayedItems
                .Skip((_currentPage - 1) * ItemsPerPage)
                .Take(ItemsPerPage)
                .ToList();
        }

        private void UpdateStatusBar()
        {
            StatusText.Text = $"{_displayedItems.Count} items in inventory";

            decimal totalValue = _displayedItems.Sum(item => item.Price * item.Quantity);
            TotalValueText.Text = $"Total Value: {totalValue.ToString("C", CultureInfo.CurrentCulture)}";

            int totalPages = (int)Math.Ceiling((double)_displayedItems.Count / ItemsPerPage);
            totalPages = totalPages == 0 ? 1 : totalPages;
            PageInfoText.Text = $"Page {_currentPage} of {totalPages}";
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv",
                Title = "Export Inventory Data"
            };

            if (saveDialog.ShowDialog() == true)
            {
                try
                {
                    var lines = new List<string> { "ID,Name,Category,Quantity,Unit,Price,LastUpdated" };
                    lines.AddRange(_displayedItems.Select(item =>
                        $"{item.Id},{item.Name},{item.Category},{item.Quantity},{item.Unit},{item.Price},{item.LastUpdated:d}"));

                    File.WriteAllLines(saveDialog.FileName, lines);

                    MessageBox.Show("Inventory exported successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void PreviousPage_Click(object sender, RoutedEventArgs e)
        {
            if (_currentPage > 1)
            {
                _currentPage--;
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            int totalPages = (int)Math.Ceiling((double)_displayedItems.Count / ItemsPerPage);
            if (_currentPage < totalPages)
            {
                _currentPage++;
                ApplyPaging();
                InventoryGrid.ItemsSource = _currentPageItems;
                UpdateStatusBar();
            }
        }

        private void InventoryGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (InventoryGrid.SelectedItem != null)
            {
                InventoryGrid.ScrollIntoView(InventoryGrid.SelectedItem);
            }
        }
    }

    public class InventoryItem : INotifyPropertyChanged
    {
        public int Id { get; set; }

        private string _name;
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        private string _category;
        public string Category
        {
            get => _category;
            set { _category = value; OnPropertyChanged(nameof(Category)); }
        }

        private int _quantity;
        public int Quantity
        {
            get => _quantity;
            set { _quantity = value; OnPropertyChanged(nameof(Quantity)); }
        }

        private string _unit;
        public string Unit
        {
            get => _unit;
            set { _unit = value; OnPropertyChanged(nameof(Unit)); }
        }

        private decimal _price;
        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged(nameof(Price)); }
        }

        private DateTime _lastUpdated;
        public DateTime LastUpdated
        {
            get => _lastUpdated;
            set { _lastUpdated = value; OnPropertyChanged(nameof(LastUpdated)); }
        }

        public InventoryItem(int id, string name, string category, int quantity, string unit, decimal price, DateTime lastUpdated)
        {
            Id = id;
            Name = name;
            Category = category;
            Quantity = quantity;
            Unit = unit;
            Price = price;
            LastUpdated = lastUpdated;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}