﻿using System.ComponentModel;

namespace InventoryManager.Models
{
    public class StockLocation : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _storeName;
        private string _stockInHand;

        public string StoreName
        {
            get => _storeName;
            set { _storeName = value; OnPropertyChanged(nameof(StoreName)); }
        }

        public string StockInHand
        {
            get => _stockInHand;
            set { _stockInHand = value; OnPropertyChanged(nameof(StockInHand)); }
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}