﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using InventoryManager.Views.Pages;

namespace InventoryManager.Controls
{
    public partial class TopNavBar : UserControl
    {
        public TopNavBar()
        {
            InitializeComponent();
            InitializeSearchBox();
        }

        private void InitializeSearchBox()
        {
            SearchBox.GotFocus += SearchBox_GotFocus;
            SearchBox.LostFocus += SearchBox_LostFocus;
            SearchBox.KeyUp += SearchBox_KeyUp;
        }

        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SearchBox.Text == "🔍 Search products, inventory...")
            {
                SearchBox.Text = "";
                SearchBox.Foreground = Brushes.Black;
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SearchBox.Text))
            {
                SearchBox.Text = "🔍 Search products, inventory...";
                SearchBox.Foreground = Brushes.Gray;
            }
        }

        private void SearchBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && !string.IsNullOrWhiteSpace(SearchBox.Text) &&
                SearchBox.Text != "🔍 Search products, inventory...")
            {
                PerformSearch();
            }
        }

        private void PerformSearch()
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            if (mainWindow == null) return;

            var currentPage = mainWindow.MainNavigationFrame.Content as BasePage;
            if (currentPage == null) return;

            currentPage.PerformSearch(SearchBox.Text.Trim());
        }

        private void ToggleSidebarBtn_Click(object sender, RoutedEventArgs e)
        {
            var mainWindow = Window.GetWindow(this) as MainWindow;
            mainWindow?.ToggleSidebar();
        }

        private void ProfileBtn_Click(object sender, RoutedEventArgs e)
        {
            // Handle profile button click
            MessageBox.Show("Profile button clicked", "Profile", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}